from flask import Flask, render_template, request
import whisper
import os
from werkzeug.utils import secure_filename

# Initialize the Flask application
app = Flask(__name__)
model = whisper.load_model("base")

# Configuration for upload folder
UPLOAD_FOLDER = "uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER

@app.route("/")
def index():
    """Render the home page with the upload form."""
    return render_template("index.html")

@app.route("/transcribe", methods=["POST"])
def transcribe():
    """Handle audio file upload and transcription."""
    if "file" not in request.files:
        return "Nenhum arquivo enviado.", 400

    file = request.files["file"]
    if file.filename == "":
        return "Nome de arquivo vazio.", 400

    filename = secure_filename(file.filename)
    filepath = os.path.join(app.config["UPLOAD_FOLDER"], filename)
    file.save(filepath)

    # Transcribe audio file
    result = model.transcribe(filepath)
    text = result["text"]

    # Remove the uploaded file after transcription
    os.remove(filepath)
    return render_template("result.html", transcription=text)

if __name__ == "__main__":
    app.run(debug=True)